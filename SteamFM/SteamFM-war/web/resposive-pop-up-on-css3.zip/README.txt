A Pen created at CodePen.io. You can find this one at http://codepen.io/31russ/pen/fjgAx.

 Resposive Pop-up window for website on css3 This window will pop-up on the page you installed it. Background will be blured to focus more on window.